function sayHi() {
	console.log("Javascript");
}

window.sayHi = sayHi;
	
