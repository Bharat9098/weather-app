// function sayHi() {
	// console.log("Javascript");
// }
// 
$('document').ready(function() {
  setTimeout(function() {
    $('#flash').slideUp();
  }, 3000);
});

// window.sayHi = sayHi;
